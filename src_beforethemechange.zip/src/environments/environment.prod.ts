export const environment = {
  production: true,
  apiUrl: 'https://naklibeta.com/api/api/provider',
};
