export const environment = {
  production: true,
  apiUrl: 'https://jobbanko.com/api/provider',
};
